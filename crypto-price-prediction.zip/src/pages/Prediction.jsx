import React, { useEffect, useState } from "react";
import { Line, Bar, Scatter } from "react-chartjs-2";
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement,
    Tooltip,
    Legend,
    Filler,
} from "chart.js";
import axios from "axios";
import "../styles/Prediction.css";

ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement,
    Tooltip,
    Legend,
    Filler
);

// API Base URL - Update this to your backend URL
const API_BASE_URL = import.meta.env.REACT_APP_API_URL || "http://localhost:5000";

const COINS = [
    { symbol: "BTC", name: "Bitcoin", emoji: "₿", color: "#f7931a" },
    { symbol: "ETH", name: "Ethereum", emoji: "Ξ", color: "#627eea" },
    { symbol: "BNB", name: "Binance Coin", emoji: "⬤", color: "#f3ba2f" },
    { symbol: "SOL", name: "Solana", emoji: "◎", color: "#9945ff" },
    { symbol: "XRP", name: "Ripple", emoji: "✕", color: "#23292f" },
];

const SIGNAL_CONFIG = {
    BUY: { color: "#10b981", icon: "📈", label: "Strong Buy Signal" },
    HOLD: { color: "#f59e0b", icon: "⏸️", label: "Hold & Monitor" },
    SELL: { color: "#ef4444", icon: "📉", label: "Strong Sell Signal" },
};



const Prediction = () => {
    const [selectedCoin, setSelectedCoin] = useState("BTC");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [forecast, setForecast] = useState(null);
    const [marketData, setMarketData] = useState(null);
    const [indicators, setIndicators] = useState(null);

    const fetchPrediction = async (coin) => {
        setLoading(true);
        setError(null);
        try {
            const response = await axios.post(`${API_BASE_URL}/api/predict`, {
                coin: coin,
                include_indicators: true,
                include_market: true,
            });

            if (response.data.success) {
                setForecast(response.data.forecast);
                setMarketData(response.data.market);
                setIndicators(response.data.indicators);
            } else {
                setError(response.data.error || "Failed to fetch prediction");
            }
        } catch (err) {
            setError(err.response?.data?.error || err.message || "Error fetching prediction");
            console.error("Prediction error:", err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchPrediction(selectedCoin);
    }, [selectedCoin]);

    const handleCoinSelect = (coinSymbol) => {
        setSelectedCoin(coinSymbol);
    };

    const currentCoin = COINS.find((c) => c.symbol === selectedCoin);
    const formatPrice = (price) => {
        if (!price) return "N/A";
        if (price >= 1000) return `$${(price / 1000).toFixed(2)}K`;
        return `$${price.toFixed(2)}`;
    };

    const formatChange = (current, forecast) => {
        if (!current || !forecast) return "N/A";
        const change = ((forecast - current) / current) * 100;
        return change.toFixed(2);
    };

    const generateChartData = () => {
        if (!forecast) return null;

        const horizons = forecast.horizons || ["1w", "1m", "3m", "6m", "1y"];
        const ensembleData = forecast.ensemble || [];

        return {
            labels: horizons,
            datasets: [
                {
                    label: "Ensemble Forecast",
                    data: ensembleData,
                    borderColor: "#667eea",
                    backgroundColor: "rgba(102, 126, 234, 0.1)",
                    fill: true,
                    tension: 0.4,
                    pointRadius: 6,
                    pointBackgroundColor: "#667eea",
                    pointBorderColor: "#fff",
                    pointBorderWidth: 2,
                },
                {
                    label: "Prophet",
                    data: forecast.prophet || [],
                    borderColor: "#3b82f6",
                    backgroundColor: "transparent",
                    borderDash: [5, 5],
                    tension: 0.4,
                },
                {
                    label: "LSTM",
                    data: forecast.lstm || [],
                    borderColor: "#10b981",
                    backgroundColor: "transparent",
                    borderDash: [5, 5],
                    tension: 0.4,
                },
            ],
        };
    };

    const chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: "bottom",
                labels: {
                    font: { size: 12 },
                    padding: 15,
                },
            },
            tooltip: {
                backgroundColor: "rgba(0, 0, 0, 0.8)",
                padding: 12,
                borderRadius: 8,
                callbacks: {
                    label: (context) => {
                        return `${context.dataset.label}: $${context.parsed.y.toFixed(2)}`;
                    },
                },
            },
        },
        scales: {
            y: {
                beginAtZero: false,
                grid: {
                    color: "rgba(0, 0, 0, 0.05)",
                },
            },
        },
    };

    const chartData = generateChartData();

    return (
        <div className="prediction-container">


            <div className="container-fluid px-lg-5">
                {/* Header */}
                <div className="prediction-header">
                    <h1 className="prediction-title">🔮 Price Prediction</h1>
                    <p className="text-muted">AI-powered crypto price forecasting with ensemble models</p>
                </div>

                {/* Error Banner */}
                {error && <div className="error-banner">⚠️ {error}</div>}

                {/* Coin Selector */}
                <div className="coin-selector">
                    {COINS.map((coin) => (
                        <button
                            key={coin.symbol}
                            className={`coin-btn ${selectedCoin === coin.symbol ? "active" : ""}`}
                            onClick={() => handleCoinSelect(coin.symbol)}
                            disabled={loading}
                        >
                            <div className="coin-btn-emoji">{coin.emoji}</div>
                            <div className="coin-btn-name">{coin.name}</div>
                            <div className="coin-btn-symbol">{coin.symbol}</div>
                        </button>
                    ))}
                </div>

                {/* Loading State */}
                {loading ? (
                    <div className="loading-spinner">
                        <div className="spinner"></div>
                    </div>
                ) : null}

                {/* Market Data */}
                {!loading && marketData && (
                    <div className="market-info">
                        <h3 className="chart-title">📊 Live Market Data</h3>
                        <div className="market-row">
                            <span className="market-label">Current Price</span>
                            <span className="market-value">{formatPrice(marketData.price)}</span>
                        </div>
                        <div className="market-row">
                            <span className="market-label">24h Change</span>
                            <span className={`market-value ${marketData.price_change_pct_24h >= 0 ? "change-positive" : "change-negative"}`}>
                                {marketData.price_change_pct_24h ? `${marketData.price_change_pct_24h.toFixed(2)}%` : "N/A"}
                            </span>
                        </div>
                        <div className="market-row">
                            <span className="market-label">24h Volume</span>
                            <span className="market-value">{formatPrice(marketData.volume_24h)}</span>
                        </div>
                        <div className="market-row">
                            <span className="market-label">Bid / Ask</span>
                            <span className="market-value">
                                {formatPrice(marketData.bid)} / {formatPrice(marketData.ask)}
                            </span>
                        </div>
                    </div>
                )}

                {/* Forecast Table */}
                {!loading && forecast && (
                    <div className="forecast-card">
                        <div className="forecast-header">
                            <h2 className="forecast-title">🎯 Price Forecast</h2>
                            <div className="current-price">{formatPrice(marketData?.price)}</div>
                        </div>

                        <table className="forecast-table">
                            <thead>
                                <tr>
                                    <th>Horizon</th>
                                    <th>Ensemble</th>
                                    <th>Change %</th>
                                    <th>95% Confidence Interval</th>
                                </tr>
                            </thead>
                            <tbody>
                                {forecast.horizons?.map((horizon, i) => (
                                    <tr key={horizon}>
                                        <td>{horizon}</td>
                                        <td className="price-cell">{formatPrice(forecast.ensemble?.[i])}</td>
                                        <td className={`change-cell ${formatChange(marketData?.price, forecast.ensemble?.[i]) >= 0 ? "change-positive" : "change-negative"}`}>
                                            {formatChange(marketData?.price, forecast.ensemble?.[i])}%
                                        </td>
                                        <td className="ci-cell">
                                            {formatPrice(forecast.ensemble_lower?.[i])} – {formatPrice(forecast.ensemble_upper?.[i])}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}

                {/* Forecast Chart */}
                {!loading && chartData && (
                    <div className="chart-card">
                        <h3 className="chart-title">📈 Forecast Comparison</h3>
                        <div className="chart-container">
                            <Line data={chartData} options={chartOptions} />
                        </div>
                    </div>
                )}

                {/* Technical Indicators */}
                {!loading && indicators && (
                    <div className="forecast-card">
                        <h3 className="chart-title">📊 Technical Indicators</h3>
                        <div className="indicators-grid">
                            {Object.entries(indicators)
                                .slice(0, 12)
                                .map(([key, value]) => (
                                    <div key={key} className="indicator-card">
                                        <div className="indicator-label">{key}</div>
                                        <div className="indicator-value">
                                            {typeof value === "number" ? value.toFixed(2) : value}
                                        </div>
                                    </div>
                                ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Prediction;
